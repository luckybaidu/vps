<?php
return array(
    'dsn'               => 'mysql:dbname=ov;host=localhost;port=3306',
    'username'          => 'root',
    'password'          => 'root2',
    'charset'           => 'utf8',
);