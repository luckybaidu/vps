-- phpMyAdmin SQL Dump
-- version 4.0.10.11
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016-10-21 23:59:53
-- 服务器版本: 5.5.50-MariaDB
-- PHP 版本: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `ov`
--

-- --------------------------------------------------------

--
-- 表的结构 `agent`
--

CREATE TABLE IF NOT EXISTS `agent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `users` int(10) NOT NULL COMMENT '限制创建账号数量',
  `limit` bigint(128) DEFAULT NULL COMMENT '可分配流量总额',
  `create` int(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1 正常 2禁用',
  `notice` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `app_line`
--

CREATE TABLE IF NOT EXISTS `app_line` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `type` int(10) DEFAULT NULL,
  `content` mediumtext,
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `app_line_type`
--

CREATE TABLE IF NOT EXISTS `app_line_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `app_line_type`
--

INSERT INTO `app_line_type` (`id`, `name`, `status`) VALUES
(1, '移动', 1),
(2, '联通', 1),
(3, '电信', 1);

-- --------------------------------------------------------

--
-- 表的结构 `app_link`
--

CREATE TABLE IF NOT EXISTS `app_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `icon` varchar(200) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `app_qrcode`
--

CREATE TABLE IF NOT EXISTS `app_qrcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `key` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `app_qrcode`
--

INSERT INTO `app_qrcode` (`id`, `name`, `logo`, `addr`, `key`) VALUES
(1, '输入你的APP名字', '/upload/qrcode/109309233b39457e4b5c7feb0734f41b.png', '输入后台地址(http://ip:7788/)', '输入购买的key');

-- --------------------------------------------------------

--
-- 表的结构 `app_set`
--

CREATE TABLE IF NOT EXISTS `app_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qq` varchar(20) DEFAULT NULL COMMENT 'qq号',
  `qqgroup` varchar(20) DEFAULT NULL COMMENT 'qq群',
  `notice` varchar(200) DEFAULT NULL COMMENT '公告',
  `url` varchar(100) DEFAULT NULL COMMENT '新版地址',
  `notice_url` varchar(100) DEFAULT NULL COMMENT '使用说明地址',
  `web_url` varchar(100) DEFAULT NULL COMMENT '官方地址',
  `buy_url` varchar(100) DEFAULT NULL COMMENT '购买地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `app_set`
--

INSERT INTO `app_set` (`id`, `qq`, `qqgroup`, `notice`, `url`, `notice_url`, `web_url`, `buy_url`) VALUES
(1, '111111', '222222', '没有公告呀呀呀呀呀', 'https://www.baidu.com/', 'https://www.baidu.com/', 'https://www.baidu.com/', 'https://www.baidu.com/');

-- --------------------------------------------------------

--
-- 表的结构 `clean`
--

CREATE TABLE IF NOT EXISTS `clean` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `notice` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `code`
--

CREATE TABLE IF NOT EXISTS `code` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `login_log`
--

CREATE TABLE IF NOT EXISTS `login_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(20) DEFAULT NULL,
  `pass` varchar(20) DEFAULT NULL,
  `info` varchar(50) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `openvpn`
--

CREATE TABLE IF NOT EXISTS `openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(16) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `dlid` int(11) DEFAULT NULL,
  `fwqid` int(11) DEFAULT '1',
  `notes` varchar(255) DEFAULT NULL,
  `tian` int(11) NOT NULL COMMENT 'VPNS',
  `status` int(11) DEFAULT '0',
  `beizhu` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `disable` int(1) DEFAULT '0' COMMENT '1 禁用',
  `online` int(1) unsigned DEFAULT '0' COMMENT '0为离线,1为在线',
  `owner` int(10) NOT NULL DEFAULT '0' COMMENT '所有者0后台 非0代理id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `iuser` (`iuser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `rbac_user`
--

CREATE TABLE IF NOT EXISTS `rbac_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `rbac_user`
--

INSERT INTO `rbac_user` (`id`, `username`, `password`) VALUES
(1, 'admin', 'e6e061838856bf47e1de730719fb2609');

-- --------------------------------------------------------

--
-- 表的结构 `server`
--

CREATE TABLE IF NOT EXISTS `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `ipport` varchar(64) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `server`
--

INSERT INTO `server` (`id`, `name`, `ipport`, `time`) VALUES
(1, '主机', '127.0.0.1:7788', 1477136307);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
